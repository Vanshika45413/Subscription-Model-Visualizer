
import React from 'react';
import { ApiEndpoint } from '../types';

interface ApiEndpointCardProps {
  endpoint: ApiEndpoint;
}

const getMethodColor = (method: ApiEndpoint['method']) => {
  switch (method) {
    case 'GET':
      return 'bg-sky-500 text-sky-50';
    case 'POST':
      return 'bg-emerald-500 text-emerald-50';
    case 'PUT':
      return 'bg-amber-500 text-amber-50';
    case 'DELETE':
      return 'bg-red-500 text-red-50';
    default:
      return 'bg-slate-500 text-slate-50';
  }
};

const ApiEndpointCard: React.FC<ApiEndpointCardProps> = ({ endpoint }) => {
  return (
    <div className="bg-white shadow-lg rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <span
          className={`px-3 py-1 text-sm font-semibold rounded-full ${getMethodColor(endpoint.method)}`}
        >
          {endpoint.method}
        </span>
        <code className="text-sm md:text-base font-mono bg-slate-100 text-slate-700 px-3 py-1 rounded">
          {endpoint.path}
        </code>
      </div>
      <p className="text-slate-700 mb-4">{endpoint.description}</p>
      {endpoint.requestBody && (
        <div className="mb-3">
          <h4 className="font-semibold text-slate-600 text-sm mb-1">Request Body Example:</h4>
          <pre className="bg-slate-800 text-slate-100 p-3 rounded-md text-xs overflow-x-auto">
            <code>{endpoint.requestBody}</code>
          </pre>
        </div>
      )}
      {endpoint.responseBody && (
         <div >
          <h4 className="font-semibold text-slate-600 text-sm mb-1">Response Body Example:</h4>
          <pre className="bg-slate-800 text-slate-100 p-3 rounded-md text-xs overflow-x-auto">
            <code>{endpoint.responseBody}</code>
          </pre>
        </div>
      )}
    </div>
  );
};

export default ApiEndpointCard;
