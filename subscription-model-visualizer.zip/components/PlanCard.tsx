
import React from 'react';
import { Plan } from '../types';
import CheckIcon from './icons/CheckIcon';

interface PlanCardProps {
  plan: Plan;
  isSelected?: boolean;
  onSelect?: (planId: Plan['id']) => void;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, isSelected, onSelect }) => {
  const cardClasses = `
    bg-white shadow-xl rounded-lg p-6 flex flex-col transition-all duration-300 ease-in-out
    hover:shadow-2xl hover:scale-105 h-full
    ${isSelected ? 'ring-4 ring-sky-500 scale-105' : 'ring-1 ring-slate-200'}
    ${onSelect ? 'cursor-pointer' : ''}
  `;

  return (
    <div className={cardClasses} onClick={onSelect ? () => onSelect(plan.id) : undefined}>
      <h3 className="text-2xl font-bold text-sky-700 mb-2">{plan.name}</h3>
      <p className="text-3xl font-extrabold text-slate-900 mb-1">
        {plan.currency}{plan.price.toFixed(2)}
      </p>
      <p className="text-sm text-slate-500 mb-6">{plan.duration}</p>
      
      <ul className="space-y-2 mb-6 flex-grow">
        {plan.features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <CheckIcon className="w-5 h-5 text-emerald-500 mr-2 flex-shrink-0" />
            <span className="text-slate-600 text-sm">{feature}</span>
          </li>
        ))}
      </ul>
      
      {onSelect && (
         <button 
          type="button"
          className={`w-full py-3 px-4 rounded-md font-semibold text-white transition-colors
            ${isSelected ? 'bg-sky-600 hover:bg-sky-700' : 'bg-slate-700 hover:bg-slate-800'}`}
        >
          {isSelected ? 'Selected' : 'Select Plan'}
        </button>
      )}
    </div>
  );
};

export default PlanCard;
