
import React, { useState, useCallback } from 'react';
import { Plan, Subscription, SubscriptionStatus, MockUser, PlanId } from '../types';
import { PLANS_DATA, MOCK_USERS } from '../constants';
import PlanCard from './PlanCard';
import ChevronDownIcon from './icons/ChevronDownIcon';

const SubscriptionSimulator: React.FC = () => {
  const [mockSubscriptions, setMockSubscriptions] = useState<Record<string, Subscription>>({});
  
  const [selectedUserIdCreate, setSelectedUserIdCreate] = useState<string>(MOCK_USERS[0]?.id || '');
  const [selectedPlanIdCreate, setSelectedPlanIdCreate] = useState<PlanId>(PLANS_DATA[0]?.id || PlanId.BASIC);
  
  const [selectedUserIdManage, setSelectedUserIdManage] = useState<string>(MOCK_USERS[0]?.id || '');
  const [currentUserSubscription, setCurrentUserSubscription] = useState<Subscription | null>(null);
  const [manageMessage, setManageMessage] = useState<string | null>(null);
  const [createMessage, setCreateMessage] = useState<string | null>(null);

  const [showUpgradeOptions, setShowUpgradeOptions] = useState<boolean>(false);
  const [selectedPlanIdUpdate, setSelectedPlanIdUpdate] = useState<PlanId | null>(null);


  const showTemporaryMessage = (setter: React.Dispatch<React.SetStateAction<string | null>>, message: string) => {
    setter(message);
    setTimeout(() => setter(null), 3000);
  };

  const handleCreateSubscription = useCallback(() => {
    if (!selectedUserIdCreate || !selectedPlanIdCreate) {
      showTemporaryMessage(setCreateMessage, 'Please select a user and a plan.');
      return;
    }

    const plan = PLANS_DATA.find(p => p.id === selectedPlanIdCreate);
    if (!plan) {
      showTemporaryMessage(setCreateMessage, 'Selected plan not found.');
      return;
    }

    const newSubscription: Subscription = {
      userId: selectedUserIdCreate,
      plan: plan,
      status: SubscriptionStatus.ACTIVE,
      subscribedDate: new Date().toISOString(),
      // Expiry can be calculated based on plan.duration in a real scenario
    };

    setMockSubscriptions(prev => ({ ...prev, [selectedUserIdCreate]: newSubscription }));
    showTemporaryMessage(setCreateMessage, `Subscription created for ${MOCK_USERS.find(u=>u.id === selectedUserIdCreate)?.name} with ${plan.name} plan.`);
    
    // If managing the same user, update their view
    if (selectedUserIdCreate === selectedUserIdManage) {
      setCurrentUserSubscription(newSubscription);
    }
  }, [selectedUserIdCreate, selectedPlanIdCreate, selectedUserIdManage]);

  const handleRetrieveSubscription = useCallback(() => {
    setShowUpgradeOptions(false);
    setSelectedPlanIdUpdate(null);
    if (!selectedUserIdManage) {
      showTemporaryMessage(setManageMessage, 'Please select a user to manage.');
      setCurrentUserSubscription(null);
      return;
    }
    const subscription = mockSubscriptions[selectedUserIdManage];
    if (subscription) {
      setCurrentUserSubscription(subscription);
      showTemporaryMessage(setManageMessage, `Subscription details for ${MOCK_USERS.find(u=>u.id === selectedUserIdManage)?.name} retrieved.`);
    } else {
      setCurrentUserSubscription(null);
      showTemporaryMessage(setManageMessage, `No active subscription found for ${MOCK_USERS.find(u=>u.id === selectedUserIdManage)?.name}.`);
    }
  }, [mockSubscriptions, selectedUserIdManage]);

  const handleUpdateSubscription = useCallback(() => {
    if (!currentUserSubscription || !selectedPlanIdUpdate) {
      showTemporaryMessage(setManageMessage, 'No subscription selected or no new plan chosen for update.');
      return;
    }
    const newPlan = PLANS_DATA.find(p => p.id === selectedPlanIdUpdate);
    if (!newPlan) {
       showTemporaryMessage(setManageMessage, 'New plan not found.');
      return;
    }

    const updatedSubscription: Subscription = {
      ...currentUserSubscription,
      plan: newPlan,
      status: SubscriptionStatus.ACTIVE, // Assuming update re-activates if it was e.g. EXPIRED
      subscribedDate: new Date().toISOString(), // Or keep old and calculate new expiry
    };
    setMockSubscriptions(prev => ({ ...prev, [currentUserSubscription.userId]: updatedSubscription }));
    setCurrentUserSubscription(updatedSubscription);
    setShowUpgradeOptions(false);
    setSelectedPlanIdUpdate(null);
    showTemporaryMessage(setManageMessage, `Subscription for ${MOCK_USERS.find(u=>u.id === currentUserSubscription.userId)?.name} updated to ${newPlan.name}.`);
  }, [currentUserSubscription, selectedPlanIdUpdate]);

  const handleCancelSubscription = useCallback(() => {
    if (!currentUserSubscription) {
      showTemporaryMessage(setManageMessage,'No subscription selected to cancel.');
      return;
    }
    const cancelledSubscription: Subscription = {
      ...currentUserSubscription,
      status: SubscriptionStatus.CANCELLED,
    };
    setMockSubscriptions(prev => ({ ...prev, [currentUserSubscription.userId]: cancelledSubscription }));
    setCurrentUserSubscription(cancelledSubscription);
    setShowUpgradeOptions(false);
    showTemporaryMessage(setManageMessage, `Subscription for ${MOCK_USERS.find(u=>u.id === currentUserSubscription.userId)?.name} has been cancelled.`);
  }, [currentUserSubscription]);
  
  const handleSetStatus = useCallback((status: SubscriptionStatus) => {
    if (!currentUserSubscription) {
      showTemporaryMessage(setManageMessage,'No subscription selected to update status.');
      return;
    }
    const updatedSubscription: Subscription = {
      ...currentUserSubscription,
      status: status,
    };
    setMockSubscriptions(prev => ({ ...prev, [currentUserSubscription.userId]: updatedSubscription }));
    setCurrentUserSubscription(updatedSubscription);
    showTemporaryMessage(setManageMessage, `Subscription status for ${MOCK_USERS.find(u=>u.id === currentUserSubscription.userId)?.name} set to ${status}.`);

  }, [currentUserSubscription]);


  const renderSelect = (id: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, options: MockUser[] | Plan[]) => (
    <div className="relative">
      <select
        id={id}
        value={value}
        onChange={onChange}
        className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-sky-500 focus:border-sky-500 appearance-none bg-white"
      >
        {options.map(opt => (
          <option key={opt.id} value={opt.id}>
            {'price' in opt ? `${opt.name} (${opt.currency}${opt.price}/${opt.duration.slice(0,2).toLowerCase()})` : opt.name}
          </option>
        ))}
      </select>
      <ChevronDownIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
    </div>
  );
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Create Subscription Section */}
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-semibold text-sky-700 mb-4">Create New Subscription</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="userCreate" className="block text-sm font-medium text-slate-700 mb-1">Select User</label>
            {renderSelect("userCreate", selectedUserIdCreate, (e) => setSelectedUserIdCreate(e.target.value), MOCK_USERS)}
          </div>
          <div>
            <label htmlFor="planCreate" className="block text-sm font-medium text-slate-700 mb-1">Select Plan</label>
            {renderSelect("planCreate", selectedPlanIdCreate, (e) => setSelectedPlanIdCreate(e.target.value as PlanId), PLANS_DATA)}
          </div>
          <button
            onClick={handleCreateSubscription}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors shadow-md"
          >
            Subscribe User
          </button>
          {createMessage && <p className="text-sm text-emerald-600 mt-2 text-center">{createMessage}</p>}
        </div>
      </div>

      {/* Manage Subscription Section */}
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-semibold text-sky-700 mb-4">Manage Existing Subscription</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="userManage" className="block text-sm font-medium text-slate-700 mb-1">Select User</label>
            <div className="flex gap-2">
              {renderSelect("userManage", selectedUserIdManage, (e) => setSelectedUserIdManage(e.target.value), MOCK_USERS)}
              <button
                onClick={handleRetrieveSubscription}
                className="bg-sky-600 hover:bg-sky-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors whitespace-nowrap shadow-md"
              >
                Get Subscription
              </button>
            </div>
          </div>

          {manageMessage && <p className="text-sm text-sky-600 mt-2 text-center">{manageMessage}</p>}

          {currentUserSubscription && (
            <div className="mt-6 p-4 border border-slate-200 rounded-lg bg-slate-50">
              <h4 className="text-lg font-semibold text-slate-800 mb-2">
                Subscription for: {MOCK_USERS.find(u => u.id === currentUserSubscription.userId)?.name}
              </h4>
              <p className="text-sm text-slate-600"><strong>Plan:</strong> {currentUserSubscription.plan.name}</p>
              <p className="text-sm text-slate-600">
                <strong>Status:</strong> 
                <span className={`font-semibold ml-1 px-2 py-0.5 rounded-full text-xs
                  ${currentUserSubscription.status === SubscriptionStatus.ACTIVE ? 'bg-emerald-100 text-emerald-700' : 
                    currentUserSubscription.status === SubscriptionStatus.CANCELLED ? 'bg-red-100 text-red-700' :
                    currentUserSubscription.status === SubscriptionStatus.EXPIRED ? 'bg-amber-100 text-amber-700' :
                    'bg-slate-100 text-slate-700'}`}>
                  {currentUserSubscription.status}
                </span>
              </p>
              <p className="text-sm text-slate-600"><strong>Subscribed:</strong> {new Date(currentUserSubscription.subscribedDate).toLocaleDateString()}</p>
              
              {!showUpgradeOptions && (
                <div className="mt-4 space-y-2 sm:space-y-0 sm:flex sm:gap-2">
                  <button
                    onClick={() => setShowUpgradeOptions(true)}
                    disabled={currentUserSubscription.status === SubscriptionStatus.CANCELLED}
                    className="w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors disabled:opacity-50 shadow"
                  >
                    Upgrade/Downgrade
                  </button>
                  <button
                    onClick={handleCancelSubscription}
                    disabled={currentUserSubscription.status === SubscriptionStatus.CANCELLED}
                    className="w-full sm:w-auto bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors disabled:opacity-50 shadow"
                  >
                    Cancel Subscription
                  </button>
                </div>
              )}
               <div className="mt-2 text-xs text-slate-500">Simulate status changes:</div>
               <div className="mt-1 flex flex-wrap gap-1">
                 {(Object.values(SubscriptionStatus) as SubscriptionStatus[]).map(status => (
                    <button key={status} onClick={() => handleSetStatus(status)} 
                      className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 px-2 py-1 rounded-md">
                      Set {status}
                    </button>
                 ))}
               </div>
            </div>
          )}

          {showUpgradeOptions && currentUserSubscription && (
            <div className="mt-6">
              <h4 className="text-md font-semibold text-slate-700 mb-2">Select new plan for {MOCK_USERS.find(u => u.id === currentUserSubscription.userId)?.name}:</h4>
              <div className="grid grid-cols-1 gap-4 mb-4">
                {PLANS_DATA.filter(p => p.id !== currentUserSubscription.plan.id).map(plan => (
                  <div 
                    key={plan.id}
                    onClick={() => setSelectedPlanIdUpdate(plan.id)}
                    className={`p-3 border rounded-lg cursor-pointer transition-all ${selectedPlanIdUpdate === plan.id ? 'bg-sky-100 border-sky-500 ring-2 ring-sky-500' : 'bg-white border-slate-300 hover:border-sky-400'}`}
                  >
                    <h5 className="font-semibold text-sky-700">{plan.name}</h5>
                    <p className="text-sm text-slate-600">{plan.currency}{plan.price.toFixed(2)} / {plan.duration}</p>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleUpdateSubscription}
                  disabled={!selectedPlanIdUpdate}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors disabled:opacity-50 shadow"
                >
                  Confirm Plan Change
                </button>
                <button
                  onClick={() => {setShowUpgradeOptions(false); setSelectedPlanIdUpdate(null);}}
                  className="flex-1 bg-slate-500 hover:bg-slate-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors shadow"
                >
                  Cancel Update
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionSimulator;
