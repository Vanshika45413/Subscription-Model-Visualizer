
import React from 'react';
import CheckIcon from './icons/CheckIcon';

interface RequirementCardProps {
  title: string;
  items: string[];
  icon?: React.ReactNode;
  titleColor?: string;
}

const RequirementCard: React.FC<RequirementCardProps> = ({ title, items, icon, titleColor = "text-sky-700" }) => {
  return (
    <div className="bg-white shadow-lg rounded-xl p-6 md:p-8 mb-8">
      <div className="flex items-center mb-6">
        {icon && <span className={`mr-3 ${titleColor}`}>{icon}</span>}
        <h2 className={`text-2xl font-semibold ${titleColor}`}>{title}</h2>
      </div>
      <ul className="space-y-3">
        {items.map((item, index) => (
          <li key={index} className="flex items-start">
            <CheckIcon className="w-5 h-5 text-emerald-500 mr-3 mt-1 flex-shrink-0" />
            <span className="text-slate-700">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RequirementCard;
