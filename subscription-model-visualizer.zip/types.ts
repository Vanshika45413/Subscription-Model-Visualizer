
export enum PlanId {
  BASIC = 'plan_basic_monthly',
  PREMIUM = 'plan_premium_monthly',
  ENTERPRISE = 'plan_enterprise_annual',
}

export interface Plan {
  id: PlanId;
  name: string;
  price: number;
  currency: string;
  features: string[];
  duration: string; // e.g., "Monthly", "Annually"
}

export enum SubscriptionStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE', // Could mean payment failed, etc. For simplicity, we might not use this extensively.
  CANCELLED = 'CANCELLED',
  EXPIRED = 'EXPIRED',
}

export interface Subscription {
  userId: string;
  plan: Plan;
  status: SubscriptionStatus;
  subscribedDate: string; // ISO Date string
  expiryDate?: string; // ISO Date string
}

export interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  requestBody?: string;
  responseBody?: string;
}

export interface MockUser {
  id: string;
  name: string;
}
