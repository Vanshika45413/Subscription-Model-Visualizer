
import { Plan, ApiEndpoint, MockUser, PlanId } from './types';

export const MOCK_USERS: MockUser[] = [
  { id: 'user_emily_123', name: 'Emily Johnson' },
  { id: 'user_michael_456', name: 'Michael Smith' },
  { id: 'user_sarah_789', name: 'Sarah Williams' },
];

export const PLANS_DATA: Plan[] = [
  {
    id: PlanId.BASIC,
    name: 'Basic Plan',
    price: 9.99,
    currency: 'USD',
    features: ['Access to core features', '5 Projects', '1GB Storage', 'Email Support'],
    duration: 'Monthly',
  },
  {
    id: PlanId.PREMIUM,
    name: 'Premium Plan',
    price: 19.99,
    currency: 'USD',
    features: ['All Basic features', 'Unlimited Projects', '10GB Storage', 'Priority Email Support', 'API Access'],
    duration: 'Monthly',
  },
  {
    id: PlanId.ENTERPRISE,
    name: 'Enterprise Plan',
    price: 499.00,
    currency: 'USD',
    features: ['All Premium features', 'Dedicated Account Manager', 'Custom Integrations', '24/7 Phone Support', 'SLA'],
    duration: 'Annually',
  },
];

export const API_ENDPOINTS_DATA: ApiEndpoint[] = [
  {
    method: 'POST',
    path: '/subscriptions',
    description: 'Create a new subscription for a user.',
    requestBody: '{ "userId": "string", "planId": "string" }',
    responseBody: '{ "subscriptionId": "string", "userId": "string", "plan": {...}, "status": "ACTIVE", ... }',
  },
  {
    method: 'GET',
    path: '/subscriptions/{userId}',
    description: "Retrieve a user's current subscription details.",
    responseBody: '{ "subscriptionId": "string", "userId": "string", "plan": {...}, "status": "ACTIVE", ... }',
  },
  {
    method: 'PUT',
    path: '/subscriptions/{userId}',
    description: "Update a user's subscription (upgrade/downgrade).",
    requestBody: '{ "newPlanId": "string" }',
    responseBody: '{ "subscriptionId": "string", "userId": "string", "plan": {...}, "status": "ACTIVE", ... }',
  },
  {
    method: 'DELETE',
    path: '/subscriptions/{userId}',
    description: "Cancel a user's subscription.",
    responseBody: '{ "message": "Subscription cancelled successfully." }',
  },
  {
    method: 'GET',
    path: '/plans',
    description: 'Retrieve all available subscription plans.',
    responseBody: '[ { "id": "string", "name": "string", "price": "number", ... }, ... ]',
  },
];

export const TECHNICAL_REQUIREMENTS: string[] = [
  'Language: Java / Python / Go (developer\'s choice)',
  'Database: MongoDB / PostgreSQL / MySQL (use ORM or raw queries)',
  'Authentication: JWT',
  'Design Principles: MVC or Clean Architecture',
  'Use environment variables for config',
  'Proper error handling & input validation',
  'RESTful API standards',
];

export const FUNCTIONAL_REQUIREMENTS_USER_SUB: string[] = [
  'Create Subscription: Users can subscribe to a plan by providing their user ID and plan details.',
  "Retrieve Subscription: Retrieve the details of a user's current subscription.",
  'Update Subscription: Allow users to upgrade or downgrade their subscription plan.',
  'Cancel Subscription: Allow users to cancel their subscription.',
];

export const FUNCTIONAL_REQUIREMENTS_PLAN_MGMT: string[] = [
  'Define subscription plans with fields like id, name, price, features, and duration.',
  'Allow retrieval of all available plans.',
];

export const FUNCTIONAL_REQUIREMENTS_SUB_STATUS: string[] = [
  'Handle subscription statuses (ACTIVE, INACTIVE, CANCELLED, EXPIRED).',
  'Automatically expire subscriptions after their duration has passed (backend responsibility).',
];

export const NON_FUNCTIONAL_REQUIREMENTS: string[] = [
  'Scalability: Design the microservice to handle a large number of subscription requests.',
  'Fault Tolerance: Implement retry mechanisms for operations like database writes or external API calls.',
  'Performance: Ensure the microservice can process requests with low latency.',
  'Security: Use JWT tokens or API keys for authentication. Ensure sensitive data is encrypted in transit and at rest.',
];

export const ASSESSMENT_CRITERIA: string[] = [
  'Code Quality: Modular, readable, and follows best practices.',
  'API Design: Intuitive and adheres to RESTful conventions.',
  'Documentation: Clear and comprehensive API docs and setup instructions.',
  'Bonus Features: Implementation of advanced requirements (e.g., message queues for async updates).',
];

export const IMPLEMENTATION_DETAILS_STACK: string[] = [
  'Backend Framework: Node.js, Go, or Java (Spring Boot)',
  'Database: PostgreSQL, MySQL, or MongoDB',
  'Message Queue (Bonus): RabbitMQ, Kafka, or Redis',
];