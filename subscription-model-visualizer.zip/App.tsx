
import React from 'react';
import RequirementCard from './components/RequirementCard';
import PlanCard from './components/PlanCard';
import ApiEndpointCard from './components/ApiEndpointCard';
import SubscriptionSimulator from './components/SubscriptionSimulator';
import { 
  PLANS_DATA, 
  API_ENDPOINTS_DATA,
  TECHNICAL_REQUIREMENTS,
  FUNCTIONAL_REQUIREMENTS_USER_SUB,
  FUNCTIONAL_REQUIREMENTS_PLAN_MGMT,
  FUNCTIONAL_REQUIREMENTS_SUB_STATUS,
  NON_FUNCTIONAL_REQUIREMENTS,
  ASSESSMENT_CRITERIA,
  IMPLEMENTATION_DETAILS_STACK
} from './constants';
import UserIcon from './components/icons/UserIcon';
import PlanIcon from './components/icons/PlanIcon';
import ApiIcon from './components/icons/ApiIcon';
import InfoIcon from './components/icons/InfoIcon';

// Define a props type for icons that SectionTitle expects
interface ExpectedIconProps {
  className?: string;
}

// Helper component for section titles
interface SectionTitleProps {
  title: string;
  icon?: React.ReactElement<ExpectedIconProps>; // Updated icon type
  description?: string;
}
const SectionTitle: React.FC<SectionTitleProps> = ({ title, icon, description }) => (
  <div className="mb-8 text-center">
    <div className="flex justify-center items-center mb-2">
      {icon && <span className="text-sky-600 mr-3">{React.cloneElement(icon, { className: "w-8 h-8" })}</span>}
      <h1 className="text-3xl md:text-4xl font-bold text-slate-800">{title}</h1>
    </div>
    {description && <p className="text-lg text-slate-600 max-w-2xl mx-auto">{description}</p>}
  </div>
);


const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-sky-50 to-slate-100 py-8 md:py-12 px-4 sm:px-6 lg:px-8">
      <header className="text-center mb-12 md:mb-16">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-sky-700 mb-3">
          Subscription Microservice Project Overview
        </h1>
    
      </header>

      <main className="max-w-7xl mx-auto space-y-16">
        
        
        {/* Functional Requirements */}
        <section id="functional-reqs">
          <SectionTitle title="Functional Requirements" icon={<UserIcon />} />
          <div className="space-y-10">
            
            <div className="bg-white shadow-xl rounded-xl p-6 md:p-8">
               <h3 className="text-2xl font-semibold text-emerald-700 mb-6 flex items-center">
                <UserIcon className="w-7 h-7 mr-3" />Subscription Management Simulator
              </h3>
              <SubscriptionSimulator />
            </div>

         
            <div className="bg-white shadow-xl rounded-xl p-6 md:p-8">
               <h3 className="text-2xl font-semibold text-emerald-700 mb-6 flex items-center">
                <PlanIcon className="w-7 h-7 mr-3" />Available Subscription Plans
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {PLANS_DATA.map(plan => <PlanCard key={plan.id} plan={plan} />)}
              </div>
            </div>

          </div>
        </section>

        

       
      </main>

      <footer className="text-center mt-16 py-8 border-t border-slate-300">
        <p className="text-slate-600">
          Subscription Model Visualizer | Vanshika Gada &copy; {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  );
};

export default App;
